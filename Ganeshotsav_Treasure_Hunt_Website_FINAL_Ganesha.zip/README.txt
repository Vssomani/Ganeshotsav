GANESHOTSAV TREASURE HUNT — VERSION 2

1. Extract the ZIP.
2. Double-click index.html.
3. On the first screen click ENTER THE CELEBRATION.
4. Enter password MORYA.
5. It transitions to the reveal screen.

To change the password or clue, open script.js and edit:
const PASSWORD="MORYA";
const NEXT_CLUE="...";

IMPORTANT: This is a client-side password. It is meant as a fun game gate, not high-security authentication.

If you see an old page, make sure you are opening THIS new version's index.html after extracting the new ZIP.
